
1) 2주전
# 2021.11.12 (예측하고자 하는 날짜) 기준, 2주 전(~10/29)까지의 180일의 데이터
< corona_data_0419_1015> 

# 불러오기
file = open('c:/data/corona_data_0503_1029.pkl', 'rb')  
corona_data_0503_1029 = pickle.load(file)          
file.close()


# 파일 불러와서 확인해보기 
corona_data_0503_1029

# pd.set_option('display.max_columns',10)  # import pandas as pd  


# 시각화 라이브러리 & 한글 표시
import matplotlib.pyplot as plt    # 시각화

from matplotlib import font_manager,rc
font_name = font_manager.FontProperties(fname='c:/windows/fonts/malgun.ttf').get_name()
rc('font', family=font_name)

# 상관계수 값 확인
corona_0503_1029_corr = corona_data_0503_1029.corr() 
corona_0503_1029_corr


# 히트맵을 그려보기 위한 시본 라이브러리
import seaborn as sns 
sns.heatmap(corona_0503_1029_corr, annot=True, cmap='coolwarm')   # 상관계수값 표시


# 변수간 관계 확인
sns.pairplot(corona_0503_1029_corr, kind='scatter', diag_kind='hist')  # 히스토그램 이용
# 상관계수 말고, 그냥 원본데이터(corona_data_0503_1029)로 넣어서 보기 
# sns.pairplot(corona_data_0419_1015, kind='scatter', diag_kind='hist')   




# 다중회귀분석으로 -> 상관분석이 있는 컬럼 확인해보기 

from sklearn.preprocessing import StandardScaler        # 사이킷런 표준화

# 표준화 ★  (스케일링 작업)
corona_data_scale = StandardScaler()      # 인스턴스화
corona_data_scale.fit(corona_data_0503_1029.iloc[:,2:])   # 피트 작업   

corona_data_0503_1029.iloc[:,2:] = corona_data_scale.transform(corona_data_0503_1029.iloc[:,2:])  # 표준화 작업한 것
corona_data_0503_1029.iloc[:,2:]

corona_data_0503_1029


from sklearn import linear_model   # 다중회귀분석

x = corona_data_0503_1029.iloc[:,2:]
y = corona_data_0503_1029['confirmed_cnt_daily']


from sklearn.model_selection import train_test_split     # 데이터 나누기  
x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.2, random_state=123)

reg = linear_model.LinearRegression()  # 인스턴스화
model = reg.fit(x_train, y_train)

print("기울기", reg.coef_)  
print("절편", reg.intercept_)   # 절편 849.789150912866



import statsmodels.api as sm 

x_train = sm.add_constant(x_train)

model = sm.OLS(y_train, x_train).fit()
model.summary()

------------------
------------------

2) 4주전
# 2021.11.12 (예측하고자 하는 날짜) 기준, 4주 전(~10/15)까지의 180일의 데이터
< corona_data_0419_1015> 

# 불러오기
file = open('c:/data/corona_data_0419_1015.pkl', 'rb')  
corona_data_0419_1015 = pickle.load(file)          
file.close()


# 파일 불러와서 확인해보기 
corona_data_0419_1015

# pd.set_option('display.max_columns',10)  # import pandas as pd  


# 시각화 라이브러리 & 한글 표시
import matplotlib.pyplot as plt    # 시각화

from matplotlib import font_manager,rc
font_name = font_manager.FontProperties(fname='c:/windows/fonts/malgun.ttf').get_name()
rc('font', family=font_name)

# 상관계수 값 확인
corona_0419_1015_corr = corona_data_0419_1015.corr() 
corona_0419_1015_corr


# 히트맵을 그려보기 위한 시본 라이브러리
import seaborn as sns 
sns.heatmap(corona_0419_1015_corr, annot=True, cmap='coolwarm')   # 상관계수값 표시


# 변수간 관계 확인
sns.pairplot(corona_0419_1015_corr, kind='scatter', diag_kind='hist')  # 히스토그램 이용
# 상관계수 말고, 그냥 원본데이터(corona_data_0503_1029)로 넣어서 보기 
# sns.pairplot(corona_data_0419_1015, kind='scatter', diag_kind='hist')   




# 다중회귀분석으로 -> 상관분석이 있는 컬럼 확인해보기 

from sklearn.preprocessing import StandardScaler        # 사이킷런 표준화

# 표준화 ★  (스케일링 작업)
corona_data_scale = StandardScaler()      # 인스턴스화
corona_data_scale.fit(corona_data_0419_1015.iloc[:,2:])   # 피트 작업   

corona_data_0419_1015.iloc[:,2:] = corona_data_scale.transform(corona_data_0419_1015.iloc[:,2:])  # 표준화 작업한 것
corona_data_0419_1015.iloc[:,2:]

corona_data_0419_1015


from sklearn import linear_model   # 다중회귀분석

x = corona_data_0419_1015.iloc[:,2:]
y = corona_data_0419_1015['confirmed_cnt_daily']


from sklearn.model_selection import train_test_split     # 데이터 나누기  
x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.2, random_state=123)

reg = linear_model.LinearRegression()  # 인스턴스화
model = reg.fit(x_train, y_train)

print("기울기", reg.coef_)  
print("절편", reg.intercept_)   # 절편 849.789150912866



import statsmodels.api as sm 

x_train = sm.add_constant(x_train)

model = sm.OLS(y_train, x_train).fit()
model.summary()

--------------------
--------------------

3) 8주전


# 2021.11.12 (예측하고자 하는 날짜) 기준, 8주 전(~9/17)까지의 180일의 데이터
< corona_data_0322_0917 >

# 불러오기
file = open('c:/data/corona_data_0322_0917.pkl', 'rb')  
corona_data_0322_0917 = pickle.load(file)          
file.close()


# 파일 불러와서 확인해보기 
corona_data_0322_0917

# pd.set_option('display.max_columns',10)  # import pandas as pd  



# 시각화 라이브러리 & 한글 표시
import matplotlib.pyplot as plt    # 시각화

from matplotlib import font_manager,rc
font_name = font_manager.FontProperties(fname='c:/windows/fonts/malgun.ttf').get_name()
rc('font', family=font_name)

# 상관계수 값 확인
corona_0322_0917_corr = corona_data_0322_0917.corr() 
corona_0322_0917_corr


# 히트맵을 그려보기 위한 시본 라이브러리
import seaborn as sns 
sns.heatmap(corona_0322_0917_corr, annot=True, cmap='coolwarm')   # 상관계수값 표시


# 변수간 관계 확인
sns.pairplot(corona_0322_0917_corr, kind='scatter', diag_kind='hist')  # 히스토그램 이용
# 상관계수 말고, 그냥 원본데이터(corona_data_0503_1029)로 넣어서 보기 
# sns.pairplot(corona_data_0322_0917, kind='scatter', diag_kind='hist')   




# 다중회귀분석으로 -> 상관분석이 있는 컬럼 확인해보기 

from sklearn.preprocessing import StandardScaler        # 사이킷런 표준화

# 표준화 ★  (스케일링 작업)
corona_data_scale = StandardScaler()      # 인스턴스화
corona_data_scale.fit(corona_data_0322_0917.iloc[:,2:])   # 피트 작업   

corona_data_0322_0917.iloc[:,2:] = corona_data_scale.transform(corona_data_0322_0917.iloc[:,2:])  # 표준화 작업한 것
corona_data_0322_0917.iloc[:,2:]

corona_data_0322_0917


from sklearn import linear_model   # 다중회귀분석

x = corona_data_0322_0917.iloc[:,2:]
y = corona_data_0322_0917['confirmed_cnt_daily']


from sklearn.model_selection import train_test_split     # 데이터 나누기  
x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.2, random_state=123)

reg = linear_model.LinearRegression()  # 인스턴스화
model = reg.fit(x_train, y_train)

print("기울기", reg.coef_)  
print("절편", reg.intercept_)   # 절편 672.6695634501632



import statsmodels.api as sm 

x_train = sm.add_constant(x_train)

model = sm.OLS(y_train, x_train).fit()
model.summary()


-----
